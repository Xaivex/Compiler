import java.util.ArrayList;
import java.util.List;

public class TSym {
    private String type;
    
    public TSym(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public String toString() {
        return type;
    }
}

class TypeDeclSym extends TSym {
	private TypeSymDef core;

	public TypeDeclSym(TypeSymDef core, String nameID) {
		super(nameID);
		this.core = core;
	}        

	public TypeSymDef getCore() {
		return this.core;
	}
}

class TypeSymDef extends TSym {
	private String type;
	private SymTable structList;

	public TypeSymDef(SymTable s, String type) {
		super(type);
		this.type = type;
        this.structList = s;
	}        

	public String getType() {
		return type;
	}
	
	public SymTable getList() {
		return this.structList;
	}

	public String toString() {
		return type;
	}
}

class FuncTSym extends TSym {
	private String type;
	private TSym param;
    private List<String> array;

	public FuncTSym(TSym param, String type) {
		super(type);
		this.type = type;
        this.param = param;
        array = new ArrayList<>();
	}        

	@Override
	public String getType() {
        if(array.size() == 0)
            return "->" + this.param.getType();
        String format = "";
        for(int i = 0;i < this.array.size();i++) {
            if(i == array.size() - 1)
                format += this.array.get(i) + "->" + this.param.getType();
            else
                format += this.array.get(i) + ",";
        }
        return format;
	}

	public void addFormals(String type) {
        this.array.add(type);
    }

	public String toString() {
		return type;
	}
}
